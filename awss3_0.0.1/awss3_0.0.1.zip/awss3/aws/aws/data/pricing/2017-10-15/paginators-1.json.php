<?php
// This file was auto-generated from sdk-root/src/data/pricing/2017-10-15/paginators-1.json
return [ 'pagination' => [ 'DescribeServices' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], 'GetAttributeValues' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], 'GetProducts' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], ],];
